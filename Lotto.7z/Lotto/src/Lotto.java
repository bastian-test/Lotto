import java.util.Arrays;

public class Lotto {

	public static void main(String[] args) {
		
		Lottozahlen Meinezahlen = new Lottozahlen(true);
		System.out.println("Ihre Gl�ckszahlen: \n" + Arrays.toString(Meinezahlen.lottozahlen));

		
		/*
		 * Gewinnklassen
		 * 1 = 1 richtige
		 * 2 = 2 richtige
		 * 3 = 3 richtige
		 * 4
		 * 5
		 * 6
		 */
		int[] Gewinnklassen = new int[7];
		/*
		 * Kosten:
		 * 1 Reihe = 1,20
		 * Grundgeb�hr = 0,50;
		 */
		
		/*
		 * Gewinne:
		 * 6 Richtige = 	1,2 Mio
		 * 5			= 	7200
		 * 4			=	36
		 * 3			= 	9
		 */
		
		double[] Gewinne = new double[7];
		Gewinne[6] = 1200000.00;
		Gewinne[5] = 7200.00;
		Gewinne[4] = 36.00;
		Gewinne[3] = 9;
		Gewinne[2] = 0;
		Gewinne[1] = 0;
		Gewinne[0] = 0;
		
		
		double Kosten = 0.0;
		
		int Abbruch = 9999999;
		Lottozahlen aktuelleZiehung = new Lottozahlen(true);
		int Gewinnrang = 0;
		for(int i=0; i<Abbruch; ++i)
		{
			aktuelleZiehung.neueZiehung();
			Kosten = Kosten + 1.20;
			//System.out.println(Arrays.toString(aktuelleZiehung.lottozahlen)+ "\n" );
			
			
			for(int f=0; f<aktuelleZiehung.lottozahlen.length; ++f)
			{
				for(int g=0; g<aktuelleZiehung.lottozahlen.length; ++g)
				{
					if(aktuelleZiehung.lottozahlen[f] == Meinezahlen.lottozahlen[g])
					{
						++Gewinnrang;
					}
				}
			}
			Gewinnklassen[Gewinnrang] = Gewinnklassen[Gewinnrang]+1;
			if(Gewinnrang>0)
			{
				//System.out.printf("Gewonnen: %d %n", Gewinnrang);
			}
			Gewinnrang = 0;
		}
		
		//Ausgabe der Spielstatistik
		for(int f=1; f<Gewinnklassen.length; ++f)
		{
			System.out.printf("Gewinne im %d - Rang: %d %n", f, Gewinnklassen[f]);
		}
		System.out.printf("Dier Spass hat %f Euro gekostet %n", Kosten);
		//Gewinnermittlung
		double Gewinntotal = 0;
		for(int f=1; f<Gewinnklassen.length; ++f)
		{
			Gewinntotal = Gewinntotal + Gewinnklassen[f] * Gewinne[f];
		}
		System.out.printf("Und Sie haben gewonnen: %f %n", Gewinntotal);
		
	}
	
	

}
