package dialog;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner leser = new Scanner(System.in);
		
		Dialog dialog = Dialog.instance();
		Dialog.Antwort antwort = Dialog.Antwort.JA;
		
		// Dialog f�hren:
		while(antwort != Dialog.Antwort.ABBRECHEN) {
			System.out.println("Weiter?");
			antwort = dialog.auswerten(leser.nextLine());
			
			switch(antwort) {
			  case JA : System.out.println("weiter");
			            break;
			  case NEIN : System.out.println("nicht weiter");
	                      break;
			  case ABBRECHEN : System.out.println("fertig");
			}
		}
		
		
		
		
		leser.close();

	}

}
