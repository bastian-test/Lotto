package dialog;


// Singleton
public class Dialog {
	public static enum Antwort {
		JA, NEIN, ABBRECHEN
	}

	// als es noch keine Enumerationen gab
//	public static final int JA        = 1;
//	public static final int NEIN      = -1;
//	public static final int ABBRECHEN = 0;

	private static Dialog dieInstanz = new Dialog();
	
	// Fabrikmethode
	public static Dialog instance() {
		return dieInstanz;
	}
	
	// verhindert weitere Instanzen
	private Dialog() {}
	
	// Auswertung
	public Antwort auswerten(String antwort) {
		switch(antwort) {
		  case "J" : // Fall Through
		  case "j" : // Fall Through
		  case "Ja" : return Antwort.JA;
		  case "N" : // Fall Through
		  case "n" : // Fall Through
		  case "nein" : return Antwort.NEIN;
		  case "a" : // Fall Through
		  case "abbrechen" : return Antwort.ABBRECHEN;
		  
		  default : throw new IllegalArgumentException(antwort + " ist nicht unterst�tzt");
		}
	}
	
}
