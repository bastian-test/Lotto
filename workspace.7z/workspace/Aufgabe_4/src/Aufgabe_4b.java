import java.util.Scanner;

public class Aufgabe_4b {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Zur verf�gung stehende Formulare
		String[] Formulare = {"Antrag Aus- und Fortbildung", "Reisekostenabrechnung", "Dienstreiseantraege"};
		int raumnummer = -1;
		Scanner scanner = new Scanner(System.in);
		while(raumnummer != 0)
		{
			System.out.printf("Bitte geben Sie eine Raummunner ein: ");
			raumnummer = scanner.nextInt();
			switch(raumnummer)
			{
			case 15:
				System.out.printf("Im B�ro No %d gibt es: %s und %s %n",raumnummer, Formulare[0], Formulare[1]);
				break;
			case 20:
				System.out.printf("Im B�ro No %d gibt es: %s %n",raumnummer, Formulare[2]);
				break;
			case 27:
				System.out.printf("Im B�ro No %d gibt es: %s %n",raumnummer, Formulare[1]);
				break;
			case 38:
				System.out.printf("Im B�ro No %d gibt es: %s %n",raumnummer, Formulare[2]);
				break;	
			default:
				System.out.printf("In B�ro No %d gibt es keine Formulare.%n", raumnummer);
				break;
			}
		}

}
}
