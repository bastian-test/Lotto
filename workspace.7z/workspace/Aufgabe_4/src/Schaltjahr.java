import java.util.Scanner;

public class Schaltjahr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Bedienungen f�rs Schaltjahr
		//Muss durch 4 teilbar sein
		//wenn durch 100 teilbar dann nein, es sei denn durch 400 teilbar
		int Pruefjahr = 1;
		Scanner scanner = new Scanner(System.in);
		System.out.printf("Bitte geben Sie eine Jahrezahl ein:");
		
		boolean istSchaltjahr = false;
		while(Pruefjahr != 0)
		{
			Pruefjahr = scanner.nextInt();
			if(Pruefjahr != 0)
			{
				if(Pruefjahr % 4 == 0) //Kann Schaltjahr sein
				{
					if(Pruefjahr % 100 == 0) //Kein Schaltjahr
					{
						if(Pruefjahr % 400 == 0)//Doch Schaltjahr 
						{
							istSchaltjahr = true;
						}
						else
						{
							istSchaltjahr = false;
						}
					}
					else
					{
						istSchaltjahr = true;
					}
				}
				else
				{
					istSchaltjahr = false;		
				}
				System.out.printf("Das Jahr %d ist %s Schaltjahr%n", Pruefjahr, istSchaltjahr?"ein":"kein");
			}
			else
			{
				System.out.printf("Das Programm wurde beendet%n");
				scanner.close();
			}
		}
	}

}
