import java.io.InputStream;
import java.util.Scanner;

public class Aufgabe_4a {

	public static void main(String[] args) {
		int zahl = 1;
		Scanner scanner = new Scanner(System.in);
		while(zahl != 0)
		{
			System.out.printf("Bitte geben Sie eine Zahl ein: ");
			zahl = scanner.nextInt();
			if(((zahl % 3) == 0) && ((zahl % 2) == 0) && (zahl != 0))
			{
				System.out.printf("Die Zahl ist durch 3 und durch 2 teilbar %n");
			}
			else if(zahl != 0)
			{
				if((zahl % 2) == 0)
				{
					System.out.printf("Die Zahl ist durch 2 teilbar %n");
				}
				else if((zahl % 3) == 0)
				{
					System.out.printf("Die Zahl ist durch 3 teilbar %n");
				}		
				else
				{
					System.out.printf("Die Zahl ist weder durch 3 noch durch 2 teilbar. %n");
				}
			}
			else
			{
				System.out.printf("Das Programm wird beendet%n");
				scanner.close();
				
			}


		}
		
	}

}
