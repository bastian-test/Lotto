# Aufgabe_7
Diese Aufgabe soll jetzt mal endlich funktionieren
