
public class OverLoad {
	
	//Berechne die Fl�che eines Quadrats
	public static long berechneFlaeche(int i)
	{
		System.out.printf("public static long berechneFlaeche(int i)%n");
		long Flaeche = i*i;
		return Flaeche;
	}
	
	//Berechne die Fl�che eines Rechtecks
	public static long berechneFlaeche(int i, int j)
	{
		System.out.printf("public static long berechneFlaeche(int i, int j)%n");
		long Flaeche = i*j;
		return Flaeche;
	}
		
	//Berechne die Fl�che eines Quadrats
	public static double berechneFlaeche(float f)
	{
		System.out.printf("public static double berechneFlaeche(float f)%n");
		float Flaeche = f*f;
		return Flaeche;
	}
		
		//Berechne die Fl�che eines Quadrats
		public static double berechneFlaeche(float f, float g)
	{
		System.out.printf("public static double berechneFlaeche(float f, float g)%n");
		float Flaeche = f*g;
		return Flaeche;
	}
						
}
