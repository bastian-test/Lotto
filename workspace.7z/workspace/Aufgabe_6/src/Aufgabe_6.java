
public class Aufgabe_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 5;
		int b = 10;
		float c = 3.7f;
		float d = 6.9f;
		System.out.printf("Flaeche: %d %n", OverLoad.berechneFlaeche(a));
		System.out.printf("Flaeche: %d %n", OverLoad.berechneFlaeche(a,b));
		System.out.printf("Flaeche: %f %n", OverLoad.berechneFlaeche(c));
		System.out.printf("Flaeche: %f %n", OverLoad.berechneFlaeche(c,d));		
	}

}
