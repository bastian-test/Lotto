
public class VerketteListe {

	public static void main(String[] args) {
		//Mit verketteten Listen Arbeiten

		Person Hauptcharakter = new Person("Bianca", "Reul", null);
		System.out.printf("Der Freund der Ehefrau ist: %s%n", Hauptcharakter.getFreund());
		Person Ehemann = new Person("Bastian", "Reul", Hauptcharakter);
		Person Arbeitskollege = new Person("Jan", "Donnert", Ehemann);
		Hauptcharakter = new Person("Bianca", "Reul",Ehemann);
		System.out.printf("Der Freund des Ehemannes ist: %s%n", Ehemann.getFreund());
		System.out.printf("Der Freund des Arbeitskollegen ist: %s%n", Arbeitskollege.getFreund());
		System.out.printf("Der Freund der Ehefrau ist: %s%n", Hauptcharakter.getFreund());
	}

}
