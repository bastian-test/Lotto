
public class Person {

	private String name;
	private String vorname;
	
	private Person freund;

	public Person(String name, String vorname) {
		this.name = name;
		this.vorname = vorname;
	}
	
	public Person(String name, String vorname, Person freund) {
		this.name = name;
		this.vorname = vorname;
		this.freund = freund;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getFreund() {
		if(freund == null)
		{
			return "Die Person hat keinen Freund.";
		}
		else
		{
			return freund.getVorname() + " " + freund.getName();
		}
	}

	public void setFreund(Person freund) {
		this.freund = freund;
	}
	
	
}
