
public class Aufgabe_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double $ = 5; //ist in Ordnung
		//		int 7Zwerge = 1;
		System.out.printf("Die Variable $ hat den Wert %f", $);
	}

}
