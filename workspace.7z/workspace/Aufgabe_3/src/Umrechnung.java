import umrechnung.zeitumrechnung.Zeitumrechnung;

public class Umrechnung {

	public static void main(String[] args) {
		Zeitumrechnung.MinutenInStunden(args[0]);
	}

}
