package umrechnung.zeitumrechnung;

public class Zeitumrechnung {

	
	/**
	 * Nimmt einen Minutenwert als String entgegen und rufe die Funktion 
	 * MinutenInStunden(int iminuten_gesammt) auf.
	 *
	 * @throws FTPConnectionException If an I/O error occurs.
	 * @throws FTPLoginException If the login operation did not succeed.
	 */
	public static void MinutenInStunden(String sminuten_gesammt)
	{
		int minuten_gesammt = Integer.parseInt(sminuten_gesammt);
		MinutenInStunden(minuten_gesammt);
	}
	
	public static void MinutenInStunden(int iminuten_gesammt)
	{
		int minuten_gesammt = iminuten_gesammt;
		int Stunden = 0;
		int Minuten = 0;
		
		Stunden = minuten_gesammt / 60;
		Minuten = minuten_gesammt % 60;
		double dStunden = ((double)minuten_gesammt) / 60.0;
		System.out.printf("%d Minuten sind %d Stunde(n) und %d Minuten oder %5.3f Stunden", minuten_gesammt, Stunden, Minuten, dStunden);

	}
}
