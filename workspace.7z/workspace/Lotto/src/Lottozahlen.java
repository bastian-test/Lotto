import java.util.Arrays;

public class Lottozahlen {
	int[] lottozahlen  = new int[6];
	private  int[] LOTTO = new int[49];
	

	public Lottozahlen()
	{
		for(int i=0; i<LOTTO.length; i+=1) {
			LOTTO[i] = i+1;
		}
	}
	
	public Lottozahlen(boolean generate)
	{
		for(int i=0; i<LOTTO.length; i+=1) {
			LOTTO[i] = i+1;
		}
		
		if(generate)
		{
			int[] positionen = new int[6];
			boolean gueltig = false;
			while(!gueltig)
			{
				int counter = 0;
				for(int i=0; i<lottozahlen.length; ++i)
				{
					positionen[i] = (int) (Math.random()*LOTTO.length+1);
				}
				Arrays.sort(positionen);
				for(int i=0; i<lottozahlen.length-1; ++i)
				{
					if(positionen[i] == positionen[i+1])
					{
						++counter;
					}
				}
				if(counter == 0)
				{
					gueltig = true;
					for(int i=0; i<lottozahlen.length; ++i)
					{
						lottozahlen[i] =positionen[i];
					}
				}
				counter = 0;
			}
		}

	}
	
	public Lottozahlen(int[] zahlen)
	{
		if(zahlen.length == 6)
		{
			for(int i=0; i<lottozahlen.length; ++i)
			{
				lottozahlen[i] = zahlen[i];
			}			
		}
		else
		{
			System.out.printf("Arraygroessen passen nicht �berein, das Array wurde nicht beschrieben%n");
		}

	}
	

	
	
	public void sortLottozahlen()
	{
		
	}
	
	public int[] rotateLottozahlen()
	{
		lottozahlen = rotate(this.lottozahlen);
		return this.lottozahlen;
	}
	
	public int[] rotate(int[] zahlen)
	{
		int[] rueckgabe = new int[zahlen.length];
		for(int i=1; i<zahlen.length-1; ++i)
		{
			rueckgabe[i] = zahlen[i+1];
		}
		rueckgabe[0] = zahlen[0+1];
		rueckgabe[rueckgabe.length-1] = zahlen[0]; 
		return rueckgabe;
	}
	
	public void neueZiehung()
	{
		if(true)
		{
			int[] positionen = new int[6];
			boolean gueltig = false;
			while(!gueltig)
			{
				int counter = 0;
				for(int i=0; i<lottozahlen.length; ++i)
				{
					positionen[i] = (int) (Math.random()*LOTTO.length+1);
				}
				Arrays.sort(positionen);
				for(int i=0; i<lottozahlen.length-1; ++i)
				{
					if(positionen[i] == positionen[i+1])
					{
						++counter;
					}
				}
				if(counter == 0)
				{
					gueltig = true;
					for(int i=0; i<lottozahlen.length; ++i)
					{
						lottozahlen[i] =positionen[i];
					}
				}
				counter = 0;
			}
		}
	}
}
