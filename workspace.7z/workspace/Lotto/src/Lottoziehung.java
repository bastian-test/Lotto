
public class Lottoziehung {

}
