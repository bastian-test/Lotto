
public class Fibonaci {

	public static void main(String[] args) {
		//Geben Sie die ersten 40 Fibonacci Zahlen aus

		int FibonaciNummer_alt = 0;
		int FibonaciNummer_neu = 1;
		int FibonaciNummer_mittel = 1;
		int Ende = 40;
		System.out.printf("Nummer %d lautet: %d %n", 1, 0);
		System.out.printf("Nummer %d lautet: %d %n", 2, 1);
		for(int i=3;i<=Ende; i++)
		{
			FibonaciNummer_neu = FibonaciNummer_alt + FibonaciNummer_mittel;
			System.out.printf("Nummer %d lautet: %d %n", i, FibonaciNummer_neu);
			FibonaciNummer_alt = FibonaciNummer_mittel;
			FibonaciNummer_mittel = FibonaciNummer_neu;
		}
	}

}
