
public class Primzahl {

	public static void main(String[] args) {
		//Geben Sie dier ersten 100 Primzahlen aus
		int ende = 100;
		int[] Zahlenarrary = new int[ende*ende];
		int[] Primzahlarray = new int[ende]; 
		
		//ein zahlenarray wird erstellt mit den Zahlen 1-100
		for(int i=1; i<ende*ende; i++)
		{
			Zahlenarrary[i]=i;
		}
		
		boolean kannPrimzahl = true;
		boolean istPrimzahl = false;
		int Primzahlkandidat = 1;
		for(int aktuelleZahl:Zahlenarrary)
		{
			int i=0;
			

				System.out.printf("Testkandidat: %d %n", aktuelleZahl);
				while(kannPrimzahl)
				{
					i++;
					System.out.printf("Testkandidat: %d %% %d = ?%n", Primzahlkandidat, Zahlenarrary[i]);
					if((Primzahlkandidat % Zahlenarrary[i]) == 0 )
					{
						 if(Primzahlkandidat == Zahlenarrary[i])
								 {
							 		System.out.printf("Primzahl gefunden: %d%n", Primzahlkandidat );
							 		istPrimzahl = true;
								 }
						 else
						 {
							 System.out.printf("Testkandidat: %d %% %d = 0, kann keine Prim sein%n", Primzahlkandidat, Zahlenarrary[i]);
							 
						 }
						 
					
					 kannPrimzahl = false;
					}
					Primzahlkandidat++;
				}
				
			
			//
			
		}

		
	}

}
