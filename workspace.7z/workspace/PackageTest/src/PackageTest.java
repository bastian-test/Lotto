import umrechnung.Zeitumrechnung;

public class PackageTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("Hier wollen wir mal testen, wie das mit den Packages funktioniert.");
		System.out.printf("Testausgabe");
	}

}
